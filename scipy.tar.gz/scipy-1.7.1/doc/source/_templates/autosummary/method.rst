:orphan:

{{ fullname }}
{{ underline }}

.. currentmodule:: {{ module }}

.. automethod:: {{ objname }}
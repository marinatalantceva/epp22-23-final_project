.. _optimize.root_scalar-toms748:

root_scalar(method='toms748')
-----------------------------

.. scipy-optimize:function:: scipy.optimize.root_scalar
   :impl: scipy.optimize._root_scalar._root_scalar_toms748_doc
   :method: toms748


.. _optimize.root-anderson:

root(method='anderson')
--------------------------------------

.. scipy-optimize:function:: scipy.optimize.root
   :impl: scipy.optimize._root._root_anderson_doc
   :method: anderson

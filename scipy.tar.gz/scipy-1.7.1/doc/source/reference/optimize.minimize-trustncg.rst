.. _optimize.minimize-trustncg:

minimize(method='trust-ncg')
-------------------------------------------

.. scipy-optimize:function:: scipy.optimize.minimize
   :impl: scipy.optimize._trustregion_ncg._minimize_trust_ncg
   :method: trust-ncg

.. _optimize.qap-faq:

quadratic_assignment(method='faq')
----------------------------------------

.. scipy-optimize:function:: scipy.optimize.quadratic_assignment
   :impl: scipy.optimize._qap._quadratic_assignment_faq
   :method: faq
